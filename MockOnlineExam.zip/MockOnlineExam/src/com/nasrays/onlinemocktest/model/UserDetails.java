package com.nasrays.onlinemocktest.model;

public class UserDetails {

	private String name;
	private String dateOfBirth;
	private String institutionName;
	private String Address;
	private String email;
	private String testIdTaken;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getInstitutionName() {
		return institutionName;
	}
	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTestIdTaken() {
		return testIdTaken;
	}
	public void setTestIdTaken(String testIdTaken) {
		this.testIdTaken = testIdTaken;
	}
	
	
}
