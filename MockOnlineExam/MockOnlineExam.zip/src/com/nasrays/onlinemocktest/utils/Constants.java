package com.nasrays.onlinemocktest.utils;

public class Constants {

	public static String NOT_ANSWERED="not_answered";
	public static String ANSWERED="answered";
	public static String NOT_VISITED="not_visited";
	public static String VISITED="visited";
	public static String REVIEW="review";
	public static String REVIEW_ANSWERED="review_answered";
}
