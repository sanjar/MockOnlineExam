function help(){
	alert("hello");
}